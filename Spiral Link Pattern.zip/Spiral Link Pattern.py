import turtle

krishna=turtle.Turtle()
s=turtle.Screen()
s.bgcolor("black")
krishna.pencolor("green")
a=0
b=0
krishna.speed(0)
krishna.penup()
krishna.goto(0,200)
krishna.pendown()

while True:
    krishna.forward(a)
    krishna.right(b)
    a+=3
    b+=1
    if b ==210:
        break
    krishna.hideturtle()


turtle.done()
